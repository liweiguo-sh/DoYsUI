﻿/*
* xwf JavaScript Library v1.0
* Author: Volant Lee
* Create Date: 2012-06-27
* Modify Date: 2017-11-10
* Copyright 2017, xpas-next.com
*/

// -- 全局常量变量及常量对象集合 ----------------------------------------------
var urlPara = getUrlPara();
var g = {
    httpServer: window.location.protocol + "//" + window.location.host,
    appPath: "/xpas/",                                  // -- WEB应用虚拟目录 --
    systemPath: "",                                     // -- 子系统目录 -- 
    local: false,                                       // -- 本地模式 --
    debug: true,                                        // -- 调试模式 --
    develop: false                                      // -- 开发者用户组模式 --
};

initConst();
function initConst() {
    var href = window.location.href;
    var nIdx = href.indexOf("/", g.httpServer.length + 1);
    // ----------------------------------------------------
    if (g.httpServer.indexOf("http") == 0) {
        g.appPath = href.substring(g.httpServer.length, nIdx + 1);
    }
    if (window.location.host.indexOf("localhost") >= 0 || window.location.protocol.indexOf("file:") == 0) {
        g.local = true;
        g.httpServer = "http://localhost:7000";             // -- WEB应用服务器(仅本机通过VS+IIS调试时用) -- 
    }
    // ----------------------------------------------------
    g.filterUrl = (g.local ? g.httpServer : "") + g.appPath + "filter.do";
    g.filterJson = (g.local ? g.httpServer : "") + g.appPath + "wis.do";
    g.controlPath = g.appPath + "res/control/"              // -- 框架控件根目录 --
    g.cssPath = g.appPath + "res/css/"                      // -- 样式根目录 --
    g.pluginPath = g.appPath + "res_plugin/"                // -- 插件控件根目录 --
    g.runPath = g.httpServer + g.appPath + "res_run/"       // -- 运行时目录(临时目录) --
    g.xpasRunPath = g.runPath + "xpas/"                     // -- 运行时目录(框架用) --    
    // ----------------------------------------------------
    g.c = { CHAR1: "\1", CHAR2: "\2", CHAR3: "\3", CHAR4: "\4", CHAR5: "\5", CHAR6: "\6", CHAR7: "\7", OK: "OK", ERR: "ERR" };
    g.a = new window.xwf_ajax();
    g.x = new window.xwf();
    g.b = g.x.b;
}

// -- 全局常用特殊函数 --------------------------------------------------------
function gId(elementId) {
    return window.document.getElementById(elementId);
}
function getParentWindow(objDoc) {
    return objDoc.defaultView || objDoc.parentWindow || window;
}

function getOffsetTop(objDOM) {
    var nTop = objDOM.offsetTop;
    var offsetParent = objDOM.offsetParent;
    while (offsetParent) {
        nTop += (offsetParent.offsetTop + offsetParent.clientTop);
        if (offsetParent.style.position.equals("relative")) break;
        offsetParent = offsetParent.offsetParent;
    }
    return nTop;
}
function getOffsetLeft(objDOM) {
    var nLeft = objDOM.offsetLeft;
    var offsetParent = objDOM.offsetParent;
    while (offsetParent) {
        nLeft += (offsetParent.offsetLeft + offsetParent.clientLeft);
        if (offsetParent.style.position.equals("relative")) break;
        offsetParent = offsetParent.offsetParent;
    }
    return nLeft;
}
function getTopOffsetTop(objDOM) {
    var nTop = objDOM.offsetTop;
    var offsetParent = objDOM.offsetParent;
    while (true) {
        if (offsetParent == null) break;
        if (offsetParent.tagName == "BODY") {
            var parentWindow = getParentWindow(offsetParent.ownerDocument);
            if (parentWindow.frameElement == null) break;                   // -- 顶级窗口(非DIV+IFRAME模拟)--
            nTop -= offsetParent.ownerDocument.documentElement.scrollTop;   // -- 窗口滚动条当前滚动高度 --
            offsetParent = parentWindow.frameElement;                       // -- 窗口的IFRAME容器 --
            nTop += (offsetParent.offsetTop + offsetParent.clientTop) + parseInt(g.x.getCurrentStyle(offsetParent, "paddingTop").replace("px"));
        }
        else if (offsetParent.tagName == "HTML") {
            //alert("???");
        }
        else {
            nTop += (offsetParent.offsetTop + offsetParent.clientTop);
        }
        offsetParent = offsetParent.offsetParent;
    }
    return nTop;
}
function getTopOffsetLeft(objDOM) {
    var nLeft = objDOM.offsetLeft;
    var offsetParent = objDOM.offsetParent;
    while (true) {
        if (offsetParent == null) break;
        if (offsetParent.tagName == "BODY") {
            var parentWindow = getParentWindow(offsetParent.ownerDocument);
            if (parentWindow.frameElement == undefined) break;                  // -- 顶级窗口(非DIV+IFRAME模拟)--
            nLeft -= offsetParent.ownerDocument.documentElement.scrollLeft;     // -- 窗口滚动条当前滚动高度 --
            offsetParent = parentWindow.frameElement;                           // -- 窗口的IFRAME容器 --
            nLeft += (offsetParent.offsetLeft + offsetParent.clientLeft) + +parseInt(g.x.getCurrentStyle(offsetParent, "paddingLeft").replace("px"));
        }
        else if (offsetParent.tagName == "HTML") {
            //alert("???");
        }
        else {
            nLeft += (offsetParent.offsetLeft + offsetParent.clientLeft);
        }
        offsetParent = offsetParent.offsetParent;
    }
    return nLeft;
}

// -- 全局页面通用函数 --------------------------------------------------------
function getUrlPara() {
    //<summary>取页面url参数, 返回JSON格式</summary>
    var arrUrlPara = window.location.search.substring(1).split('&');
    var jsonUrlPara = {};
    for (var i = 0; i < arrUrlPara.length; i++) {
        var arrPara = arrUrlPara[i].split("=");
        if (arrPara.length == 2) {
            jsonUrlPara[decodeURIComponent(arrPara[0].trim())] = decodeURIComponent(arrPara[1].trim());
        }
    }
    return jsonUrlPara;
}

function setLocalItem(itemKey, itemValue) {
    if (window.localStorage) {
        window.localStorage.setItem(itemKey, itemValue);
    }
    else {
        setCookie(itemKey, itemValue);
    }
}
function getLocalItem(itemKey) {
    var itemValue = "";
    if (window.localStorage) {
        itemValue = window.localStorage.getItem(itemKey);
    }
    else {
        itemValue = getCookie(itemKey);
    }
    if (itemValue == null) itemValue = "";
    return itemValue;
}
function setCookie(itemKey, itemValue) {
    var blFind = false;
    var n1 = 0, n2 = 0;

    var xpasCookie = "xpasCookie";
    var cookies = document.cookie;
    var arrCookie = null;
    var arrCookies = new Array();

    var expiredDate = new Date();
    // ----------------------------------------------------
    if (cookies.length > 0) {
        n1 = cookies.indexOf(xpasCookie + "=");
        if (n1 >= 0) {
            cookies = cookies.substring(n1 + xpasCookie.length + 1);
        }
        n2 = cookies.indexOf(";");
        if (n2 > 0) {
            cookies = cookies.substring(0, n2);
        }
        cookies = unescape(cookies);
    }
    if (cookies.length > 0) {
        arrCookies = cookies.split(g.c.CHAR1);
        for (var i = 0; i < arrCookies.length; i++) {
            arrCookie = arrCookies[i].split(g.c.CHAR2);
            if (arrCookie[0].equals(itemKey)) {
                arrCookies[i] = itemKey + g.c.CHAR2 + itemValue;
                blFind = true;
                break;
            }
        }
    }
    if (!blFind) {
        arrCookies.push(itemKey + g.c.CHAR2 + itemValue);
    }

    expiredDate.setDate(expiredDate.getDate() + 3650);
    document.cookie = xpasCookie + "=" + escape(arrCookies.join(g.c.CHAR1)) + ";expires=" + expiredDate.toGMTString() + ";path=/";
}
function getCookie(itemKey) {
    var blFind = false;
    var n1 = 0, n2 = 0;

    var itemValue = "";
    var xpasCookie = "xpasCookie";
    var cookies = document.cookie;
    var arrCookie = null;
    var arrCookies = new Array();
    // ----------------------------------------------------
    if (cookies.length > 0) {
        n1 = cookies.indexOf(xpasCookie + "=");
        if (n1 >= 0) {
            cookies = cookies.substring(n1 + xpasCookie.length + 1);
        }
        n2 = cookies.indexOf(";");
        if (n2 > 0) {
            cookies = cookies.substring(0, n2);
        }
        cookies = unescape(cookies);
    }
    arrCookies = cookies.split(g.c.CHAR1);
    for (var i = 0; i < arrCookies.length; i++) {
        arrCookie = arrCookies[i].split(g.c.CHAR2);
        if (arrCookie[0].equals(itemKey)) {
            itemValue = arrCookie[1];
            break;
        }
    }

    return itemValue;
}

// -- 消息对话框 --------------------------------------------------------------
function showMsg(strMessage) {
    alert(strMessage);
}
function showOK() {
    alert("系统消息：\n\n" + "当前操作成功完成。");
}
function showWarn(strMessage) {
    alert("警告：\n\n" + strMessage);
}
function showErr(strMessage) {
    alert(strMessage);
}
function showConfirm(strMessage) {
    return confirm(strMessage);
}

function showWait() {
    if (!top.divWait) {
        top.divWait = top.document.createElement("DIV");
        top.document.body.appendChild(top.divWait);
        top.divWait.className = "divWait";
        top.divWait.style.top = "0px";
        top.divWait.style.left = "0px";
        top.divWait.style.width = top.document.body.offsetWidth + "px";
        top.divWait.style.height = top.document.body.offsetHeight + "px";
        //top.divWait.style.backgroundImage = "url('res/images/frame/loading.gif')"; 
    }
    top.divWait.style.display = "";
}
function hideWait() {
    top.divWait.style.display = "none";
}

function showDebug(strMessage) {
    if (debug) {
        alert(strMessage);
    }
}

// -- 拷贝对象 ----------------------------------------------------------------
function clone(o) {
    if (!o) {
        return o;
    }
    else {
        var c;
        if (Object.prototype.toString.apply(o) === '[object Array]') {
            c = [];
            for (var i = 0; i < o.length; i++) {
                c.push(clone(o[i]));
            }
            // 采用这种判断，而非typeof(o) === 'object'，这里只处理Object，  
            //而不处理其他包括Array、String、Date、Function等，但由new创建的Function对象的也是Object
        }
        else if (Object.prototype.toString.call(o) === '[object Object]') {
            c = {};
            for (var p in o) {
                c[p] = clone(o[p]);
            }
        }
        else {
            return o;
        }
        return c;
    }
}

// -- 开发调试函数 ------------------------------------------------------------
function debug(strMessage, more) {
    ///<summary>调试信息输出。参数more默认值为false，清空之前的调试信息</summary>
    ///<param name="strMessage">调试信息</param>
    ///<param name="more">true：追加输出，false：清空之前的调试信息，单独输出</param>

    if (!g.debug && !g.local && !topWin.isDeveloper) return;
    var divDebug = top.window.document.getElementById("divDebug");
    if (divDebug == null) {
        divDebug = top.document.createElement("DIV");
        top.document.body.appendChild(divDebug);
        divDebug.id = "divDebug";
        divDebug.style.position = "absolute";
        divDebug.style.width = "400px";

        divDebug.style.top = (0) + "px";
        divDebug.style.backgroundColor = "White";

        divDebug.style.zIndex = 99999;
        divDebug.style.overflow = "auto";
        divDebug.style.padding = "1px";
        divDebug.style.border = "dotted 1px blue";

        if (!g.b.ie && !g.local) {
            divDebug.style.width = top.document.documentElement.offsetWidth + "px";
            divDebug.style.top = (400) + "px";
        }
        divDebug.style.left = (top.document.documentElement.offsetWidth - divDebug.offsetWidth) + "px";
    }
    divDebug.style.display = "";
    divDebug.onclick = function () {
        divDebug.innerHTML = "";
        divDebug.style.display = "none";
    };
    //-----------------------------------------------------
    if (more) {
        divDebug.innerHTML += "<br />" + (new Date()).toString("hh:mm:ss.ms") + " - " + strMessage;
    }
    else {
        divDebug.innerHTML = (new Date()).toString("hh:mm:ss.ms") + " - " + strMessage;
    }
}