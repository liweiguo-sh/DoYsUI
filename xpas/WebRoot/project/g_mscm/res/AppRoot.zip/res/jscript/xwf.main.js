﻿var topWin = {                          // -- 全局对象 --
    os: urlPara.os,                     // -- 客户端操作系统 --
    systemName: "",                     // -- 子系统名称(例如：xpas，即项目目录) --
    serverName: "",                     // -- 服务端部署实例名称 --
    loginUrl: urlPara["loginUrl"] || (g.appPath + "project/xpas/html/login.html"),   // -- 登录来源url --
    up: {},                             // -- user parameters 每个子系统下传 --

    eoId: 0,
    doId: 0,
    office0Id: 0,
    office0Name: "",
    office0Shortname: "",    
    office1Id: 0,
    office1Name: "",
    officeId: 0,    
    officeName: "",    
    officeNodeKey: "",
    officeShortname: "",

    userKey: "",
    userName: "",
    nickname: "",
    groupKeys: "",
    isDeveloper: false,

    win: window,
    doc: document,
    cWin: null,                 // -- 窗口集合类实例 --    
    cMenu: null,                // -- 主菜单类实例 --
    cStatusBar: null,           // -- 状态栏类实例 --

    dropgrid: new window.xwf_dropgrid(),    // -- 全局下拉框实例 --
    context: new window.xwf_context(),      // -- 全局上下文菜单实例 --
    dtbMenu: null,                          // -- 菜单记录集 --
    remark: ""
};

// -- 打开菜单 ----------------------------------------------------------------
topWin.openMenu = function (para) {
    // -- para格式样例：{ menuKey: "X81004001001" } --
    topWin.cMenu.openMenu(para);
};

// -- 打开窗口、全屏窗口、顶级视图 --------------------------------------------
topWin.openWindow = function (prop, para) {
    prop.topWin = this;
    return topWin.cWin.openWindow(prop, para);
};
topWin.openFullWindow = function (prop, para) {
    prop.noTitle = true;
    prop.windowState = "maximized";
    return this.openWindow(prop, para);
};

topWin.openView = function (prop, para) {
    var _prop = {
        modal: true,
        width: topWin.cWin.maxWidth * 0.7,
        height: topWin.cWin.maxHeight * 0.7,
        url: g.appPath + "project/xpas/html/frame/uview.html"
    };
    prop = g.x.extendJSON(_prop, prop);
    return this.openWindow(prop, para);
};
topWin.openTopView = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/frame/uview.html";
    return this.openFullWindow(prop, para);
};
topWin.openSelectView = function (prop, para) {
    var _prop = {
        modal: true,
        width: topWin.cWin.maxWidth * 0.7,
        height: topWin.cWin.maxHeight * 0.7,
        url: g.appPath + "project/xpas/html/frame/uview.html"
    };
    prop = g.x.extendJSON(_prop, prop);
    var _para = {
        viewKey: "",
        viewForm: "",
        onceFilter: "",
        viewMode: "singleSelect",   // -- singleSelect：默认单选；multiSelect：不限制 --
        selectCallback: null,       // -- 回调函数 --
        callbackPara: null           // -- 主调方参数, 原样传给回调函数 --
    };
    para = g.x.extendJSON(_para, para);
    return this.openWindow(prop, para);
};

topWin.openSelectTree = function (prop, para) {
    var _prop = {
        width: topWin.cWin.maxWidth * 0.25,
        height: topWin.cWin.maxHeight * 0.7,
        title: "数据选择树窗口",
        modal: true,
        url: g.appPath + "project/xpas/html/tree/select_tree.html"
    };
    prop = g.x.extendJSON(_prop, prop);
    var _para = {
        selectMode: "singleSelect"    // -- singleSelect：默认单选；multiSelect：不限制 --
    };
    para = g.x.extendJSON(_para, para);
    return this.openWindow(prop, para);
};
topWin.openReport = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/report/reportview.html";
    return this.openFullWindow(prop, para);
};
topWin.openFlowData = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/flow/flow_data.html";
    prop.modal = true;

    return this.openWindow(prop, para);
}

// -- 文件选择、上传、下载 ----------------------------------------------------
topWin.selectFile = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/util/select_file.html";
    prop.modal = true;

    para = g.x.extendJSON({ fileName: "", extType: "" }, para);
    return this.openWindow(prop, para);
}
topWin.uploadFile = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/util/upload_file.html";
    prop.modal = true;

    para = g.x.extendJSON({ fileName: "", uploadType: "" }, para);
    return this.openWindow(prop, para);
}
topWin.downloadFile = function (urlFile) {
    window.open(g.xpasRunPath + urlFile + "?rnd=" + Math.random());
};

// -- 辅助函数 ---------------------------------------------------------------
topWin.matchGroup = function (strGroupKeys) {
    if (strGroupKeys == null || strGroupKeys.equals("")) return false;
    var arrKeys = this.groupKeys.split(",");

    strGroupKeys = "," + strGroupKeys.toLowerCase().replaceAll(";", ",") + ",";
    for (var i = 0; i < arrKeys.length; i++) {
        if (strGroupKeys.indexOf("," + arrKeys[i].toLowerCase() + ",") >= 0) {
            return true;
        }
    }
    return false;
};
topWin.matchUser = function (strUserKeys) {
    if (strUserKeys == null || strUserKeys.equals("")) return false;
    var arrKeys = strUserKeys.replaceAll(";", ",").split(",");
    for (var i = 0; i < arrKeys.length; i++) {
        if (this.userKey.equals(arrKeys[i])) {
            return true;
        }
    }
    return false;
};

// -- 状态栏 ------------------------------------------------------------------
topWin.showStatus = function (strStatus, blFlash) {
    top.showStatus(strStatus, blFlash);
    // top.showStatus("<marquee scrollamount='2' onMouseOver='this.stop()' onMouseOut='this.start()' >" + strStatus + "</marquee>");    
}
topWin.showMsgTray = function (numMessage, menuKey) {
    var td = gId("tdMessageCount");
    if (numMessage > 0) {
        td.innerHTML = numMessage;
        td.onclick = function () {
            topWin.openMenu({ menuKey: menuKey });
        }
    }
    else {
        td.innerHTML = "";
        td.onclick = "当前没有通知。";
    }
}