﻿/*
* xwf.ajax JavaScript Library v1.0
* Author: Volant Lee
* Create Date: 2012-06-27
* Copyright 2012-2018, xpas-next.com
* Description: AJAX
* Modify Date: 2018-04-12
* Support JSON
*/
window.xwf_ajax = function () {
};
window.xwf_ajax.prototype = {
    appMode: false,                 // -- false：默认值，浏览器模式；true：APP(外壳)模式 --
    xmlHttp: this.xmlHttp,
    contentType: "application/x-www-form-urlencoded",
    url: "",
    postData: "",
    responseText: this.responseText,
    cReturn: this.cReturn,
    OK: false,
    ErrMessage: ""
};
// -- 同步请求 ----------------------------------------------------------------
window.xwf_ajax.prototype.send = function (url, dataPOST, autoShowErr) {
    return this.httpSend(url, dataPOST, "application/x-www-form-urlencoded", autoShowErr);
};
window.xwf_ajax.prototype.sendJson = function (url, dataPOST, autoShowErr) {
    return this.httpSend(url, dataPOST, "application/json", autoShowErr);
};
window.xwf_ajax.prototype.httpSend = function (url, dataPOST, contentType, autoShowErr) {
    ///<summary>ajax同步get/post方式</summary>
    ///<param name="url">web service url</param>
    ///<param name="dataPOST">post方式, 支持json格式</param>
    ///<param name="contentType">提交格式</param>

    // -- 1、提交Ajax请求 ---------------------------------
    try {
        this.contentType = contentType;

        this.checkAjaxAppMode();
        this.parseUrl(url);
        this.parseData(dataPOST);
        if (this.appMode) {
            this.responseText = App.ajaxSend(this.url, this.postData);
        }
        else {
            var d1 = new Date();
            this.xmlHttp = this.getXMLHttpRequest();
            if (this.postData) {
                this.xmlHttp.open("POST", this.url, false);
                this.xmlHttp.setRequestHeader("Content-Type", this.contentType);
                this.xmlHttp.send(this.postData);
            }
            else {
                this.xmlHttp.open("GET", this.url, false);
                this.xmlHttp.setRequestHeader("Content-Type", this.contentType);
                this.xmlHttp.send();
            }
            this.writeLog(d1);
        }
    }
    catch (e) {
        showErr("ajax.send 遇到未知错误:\n" + e.toString());
        return false;
    }

    // -- 2、检查是否正常返回 -----------------------------
    if (this.appMode) {
    }
    else {
        if (this.xmlHttp.status != 200) {
            if (this.xmlHttp.status == 400) {
                showErr("ajax返回 400 错误，可能是请求 url 中含有中文， 请检查。\n\n" + this.url);
            }
            else {
                showErr(this.xmlHttp.statusText + "  -  " + this.xmlHttp.status + "\n\n" + this.xmlHttp.responseText);
            }
            return false;
        }
        this.responseText = this.xmlHttp.responseText;
    }

    // -- 3、取得返回结果并预处理 -------------------------
    this.cReturn = this.parseResponseText(this.responseText);
    this.OK = this.cReturn.OK;
    if (!this.OK && !this.cReturn.notLogin) {
        this.ErrMessage = this.cReturn.ErrMessage;
        if (autoShowErr) {
            showErr(this.ErrMessage);
        }
    }
    return true;
}

// -- 异步请求 ----------------------------------------------------------------
window.xwf_ajax.prototype.sendAsync = function (url, dataPOST, callback, autoShowErr) {
    ///<summary>ajax异步get/post方式</summary>
    ///<param name="url">webservice or servlet url, 支持json格式</param>
    ///<param name="dataPOST">post method, 支持json格式</param>

    try {
        this.contentType = "application/x-www-form-urlencoded";

        this.xmlHttp = this.getXMLHttpRequest();
        this.parseUrl(url);
        this.parseData(dataPOST);
        if (this.postData) {
            this.xmlHttp.open("POST", this.url, true);
            this.xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            this.xmlHttp.onreadystatechange = this.asyncCallback(this.xmlHttp, callback, autoShowErr);
            this.xmlHttp.send(this.postData);
        }
        else {
            this.xmlHttp.open("GET", this.url, true);
            this.xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            this.xmlHttp.onreadystatechange = this.asyncCallback(this.xmlHttp, callback, autoShowErr);
            this.onreadystatechange = this.asyncCallback;
            this.xmlHttp.send();
        }
    }
    catch (e) {
        showErr("ajax.send 遇到未知错误:\n" + e.toString());
        return false;
    }
    return true;
};
window.xwf_ajax.prototype.asyncCallback = function (xmlHttp, callback, autoShowErr) {
    return function () {
        if (xmlHttp.readyState == 4) {
            var cReturn = window.xwf_ajax.prototype.parseResponseText(xmlHttp.responseText, autoShowErr);
            if (cReturn.OK == false && autoShowErr == true) {
                showErr(cReturn.ErrMessage);
            }
            if (callback) {
                callback(cReturn);
            }
        }
    }
};

// -- 请求参数预处理 -------------------------------------------------------------
window.xwf_ajax.prototype.checkAjaxAppMode = function () {
    ///<summary>判断ajax是否通过App外壳与服务端通讯</summary> 
    if (window.topWin) window.offline = window.topWin.offline;
    if (window.offline) {
        // -- 页面或顶级页面明确指定脱机模式(脱机模式必需引用xmf.app.js) --
        if (!window.App) {
            throw ("脱机模式页面必需引用xmf.app.js，请检查。");
        }
        if (App.os.equals("")) {
            App.os = topWin.os;
        }
        if (App.os.equals("")) {
            throw ("App内部通讯无响应，请稍后再试。");
        }
        if (!App.os.equals("windows")) {
            this.appMode = true;
        }
        else {
            // -- 非App(windows + ie调试模式)环境模式 --
        }
    }
    else {
        // -- 非脱机模式(即使app模式，也是app外壳，内嵌浏览器联机模式) --
    }
};
window.xwf_ajax.prototype.getXMLHttpRequest = function () {
    var xmlHttp1;
    if (g.b.ie) {
        xmlHttp1 = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest) {
        xmlHttp1 = new XMLHttpRequest();
        xmlHttp1.overrideMimeType('text/xml');
    }
    return xmlHttp1;
};

window.xwf_ajax.prototype.parseUrl = function (url) {
    this.cReturn = {};
    this.OK = false;
    this.ErrMessage = "";

    url = url.trim();
    if (url.indexOf("http://") < 0) {     // -- 相对路径 --
        url = g.filterUrl + "?" + url;
    }
    url += "&debug=" + (g.debug ? "1" : "0") + "&rnd=" + Math.random();
    this.url = url;
};
window.xwf_ajax.prototype.parseData = function (dataPOST) {
    if (!dataPOST) {
        this.postData = null;
    }
    else if ((typeof (dataPOST)).equals("string")) {
        this.postData = dataPOST;
    }
    else {
        if (this.contentType.equals("application/json")) {
            this.postData = JSON.stringify(dataPOST);
        }
        else {
            try {
                var arrData = new Array();
                for (var key in dataPOST) {
                    arrData.push(key + "=" + encodeURIComponent(dataPOST[key]));
                }
                this.postData = arrData.join("&");
            }
            catch (e) {
                showErr("不支持的Data对象, 参数dataPOST格式有误.");
            }
        }
    }
};

// -- 返回结果处理 ------------------------------------------------------------------
window.xwf_ajax.prototype.parseResponseText = function (responseText) {
    if (this.contentType.equals("application/json")) {
        return this.parseResponseText_json(responseText);
    }
    else {
        return this.parseResponseText_urlencoded(responseText);
    }
}
window.xwf_ajax.prototype.parseResponseText_json = function (responseText) {
    var cReturn = {};
    var datatype = "";

    var jo = null;
    // ----------------------------------------------------
    try {
        cReturn = eval("cReturn = " + responseText);

        for (var key in cReturn) {
            jo = cReturn[key];
            if (jo["datatype"].equals("bool")) {
                cReturn[key] = jo["value"].equals("true");
            }
            else if (jo["datatype"].equals("int")) {
                cReturn[key] = parseInt(jo["value"]);
            }
            else if (jo["datatype"].equals("datatable")) {
                var dtb = new xwf_datatable();
                var arr = jo["value"].split(g.c.CHAR7);
                dtb.readFromData(arr[0], arr[1]);
                cReturn[key] = dtb;
            }
            else {
                cReturn[key] = jo["value"];
            }
        }
    }
    catch (e) {
        cReturn.OK = false;
        cReturn.ErrMessage = e.toString() + "\n" + responseText;
    }
    return cReturn;
}
window.xwf_ajax.prototype.parseResponseText_urlencoded = function (responseText) {
    var cReturn = {};
    var arrReturn = responseText.split(g.c.CHAR6);
    // ----------------------------------------------------
    cReturn.OK = (arrReturn[0] == g.c.OK);
    if (cReturn.OK) {
        for (var i = 1; i < arrReturn.length; i++) {
            var arrValues = arrReturn[i].split(g.c.CHAR7);
            if (arrValues[0] == "text") {
                cReturn[arrValues[1]] = arrValues[2];
            }
            else if (arrValues[0].equals("int")) {
                cReturn[arrValues[1]] = parseInt(arrValues[2]);
            }
            else if (arrValues[0].equals("datatable")) {
                var dtb = new xwf_datatable();
                d1 = new Date();
                dtb.readFromData(arrValues[2], arrValues[3]);
                var n = g.x.timeInterval(d1, new Date())
                if (n > 1) {
                    debug("转换 " + arrValues[1] + "耗时: " + n + "。", true);
                }
                d1 = new Date();

                cReturn[arrValues[1]] = dtb;
            }
            else {
                showErr("ajax error, unknown return data type: " + arrValues[0]);
            }
        }
    }
    else {  //-- 错误信息 -------------
        if (arrReturn.length == 1) {
            if (arrReturn[0].equals("notLogin")) {
                cReturn.notLogin = true;
                alert("您尚未登录系统，或会话超时，请重新登录。");
                top.window.document.location = topWin.loginUrl + "?urlMain=" + top.window.document.location;
            }
            else {
                // -- do nothing ... --
            }
        }

        var strErrMsg = "";
        for (var i = arrReturn.length - 1; i > 0; i--) {
            var arrValues = arrReturn[i].split(g.c.CHAR7);
            strErrMsg += "\n" + arrValues[0];
            if (g.debug && arrValues[1] != "") {
                strErrMsg += "\n" + arrValues[1];
            }
            strErrMsg += "\n";
        }
        if (strErrMsg.length > 0) {
            strErrMsg = strErrMsg.substring(1);
        }
        cReturn.ErrMessage = strErrMsg;
    }
    // ----------------------------------------------------
    return cReturn;
};

// -- 下载js文件、下载web页面 -----------------------------------------------------
window.xwf_ajax.prototype.attachJavaScriptFile = function (jsFileUrl) {
    ///<summary>ajax同步方式下载服务器javaScript文件，并同步动态加载JavaScript文件</summary>
    ///<param name="jsFileUrl">javaScript文件Url</param>
    // -- 1、提交请求，下载js文件 -------------------------
    try {
        this.xmlHttp = this.getXMLHttpRequest();
        this.xmlHttp.open("GET", jsFileUrl, false);
        this.xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        this.xmlHttp.send();
    }
    catch (e) {
        showErr("ajax.attachJavaScriptFile 遇到未知错误. \n" + e.toString());
        return false;
    }
    // -- 2、检查是否正常返回 -----------------------------    
    if (this.xmlHttp.status != 200) {
        if (this.xmlHttp.status == 404) {
            if (jsFileUrl.indexOf("/js/view.") < 0 && jsFileUrl.indexOf("/js/extra_view.js") < 0) {
                showErr("404, JavaScript资源文件:\n\n" + jsFileUrl + "\n\n不存在, 请检查.");
            }
        }
        else {
            showErr(this.xmlHttp.statusText + "  -  " + this.xmlHttp.status + "\n\n" + this.xmlHttp.responseText);
        }
        return false;
    }
    this.responseText = this.xmlHttp.responseText;
    // -- 3、动态加载javaScript文件 -----------------------
    var oHead = document.getElementsByTagName('HEAD').item(0);
    var oScript = document.createElement("script");
    oScript.language = "javascript";
    oScript.type = "text/javascript";
    oScript.text = this.responseText;
    oScript.defer = true;

    oHead.appendChild(oScript);
    // -- 4、End ------------------------------------------
    return true;
};
window.xwf_ajax.prototype.getWebPageContent = function (urlWebPage) {
    ///<summary>ajax同步方式下载Web页面文件，返回文件内容</summary>
    ///<param name="urlWebPage">web页面Url</param>
    // -- 1、提交请求，下载web文件 ------------------------
    try {
        this.xmlHttp = this.getXMLHttpRequest();
        this.xmlHttp.open("GET", urlWebPage, false);
        this.xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        this.xmlHttp.send();
    }
    catch (e) {
        showErr("ajax.getWebPageContent 遇到未知错误. \n" + e.toString());
        return "";
    }
    // -- 2、检查是否正常返回 -----------------------------    
    if (this.xmlHttp.status != 200) {
        if (this.xmlHttp.status == 404) {
            showErr("404, web页面文件:\n\n" + urlWebPage + "\n\n不存在, 请检查.");
        }
        else {
            showErr(this.xmlHttp.statusText + "  -  " + this.xmlHttp.status + "\n\n" + this.xmlHttp.responseText);
        }
        return "";
    }
    this.responseText = this.xmlHttp.responseText;
    // -- 3、End ------------------------------------------
    return this.responseText;
};
// -- 调试日志 ------------------------------------------------------------------
window.xwf_ajax.prototype.writeLog = function (d1) {
    if (!window.topWin || !topWin.cStatusBar) return;
    if (!g.debug && !g.local && !topWin.isDeveloper) return;

    var nIdx = 0;
    var totalTime = 0;
    var strTemp = this.url.substring(0, 200);
    var d2 = new Date();
    var log = {
        processType: "",
        actionType: "",
        interval: 0,
        time: d2,
        timeString: d2.toString("mm:ss")
    };
    var arrOut = new Array();
    // ----------------------------------------------------
    log.interval = g.x.timeInterval(d1, d2);

    nIdx = strTemp.indexOf("processType");
    strTemp = strTemp.substring(nIdx + 12);
    nIdx = strTemp.indexOf("&");
    log.processType = strTemp.substring(0, nIdx);

    nIdx = strTemp.indexOf("actionType");
    strTemp = strTemp.substring(nIdx + 11);
    nIdx = strTemp.indexOf("&");
    log.actionType = strTemp.substring(0, nIdx);

    if (!this.arrLog) {
        this.arrLog = new Array();
    }
    this.arrLog.push(log);
    // ----------------------------------------------------
    for (var i = this.arrLog.length - 1; i >= 0; i--) {
        if (g.x.timeInterval(this.arrLog[i].time, d2) > 5) break;

        arrOut.push(this.arrLog[i].actionType + ": " + this.arrLog[i].interval);
        totalTime += this.arrLog[i].interval;
    }
    topWin.cStatusBar.showMessage("耗时：" + totalTime.toFixed(3) + ", &nbsp;&nbsp;" + arrOut.join(";&nbsp;&nbsp;"), false);
};