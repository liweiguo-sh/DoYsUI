﻿基础类调用顺序
    <!-- 基础类 -->
	<script src="../../../../res/jscript/xwf.js" type="text/javascript"></script>
	<script src="../../../../res/jscript/xwf.ajax.js" type="text/javascript"></script>	
	<script src="../../../../res/jscript/xwf.const.js" type="text/javascript"></script>


类开发样例参考：xwf_tree.js