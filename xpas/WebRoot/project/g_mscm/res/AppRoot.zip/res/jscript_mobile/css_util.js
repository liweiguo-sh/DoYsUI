﻿function setTooltipCSS(dom) {
    var textContent = "";
    if (dom.tagName.equals("TEXTAREA")) {
        if (dom.className.indexOf("inputTooltip") >= 0) {
            var arrCSS = dom.className.replace("inputTooltip","").split(" ");
            for (var i = 0; i < arrCSS.length; i++) {
                arrCSS[i] = arrCSS[i].replaceAll (" ", "");
            }
            dom.className = arrCSS.join(" ").trim();
            dom.value = "";            
        }
    }
}