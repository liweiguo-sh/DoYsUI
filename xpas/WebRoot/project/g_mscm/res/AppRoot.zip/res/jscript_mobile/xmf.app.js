﻿function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function () { document.documentElement.removeChild(WVJBIframe) }, 0)
}
setupWebViewJavascriptBridge(function (bridge) {

})

var App = {
    os: "",
    getOS: function (seccus) {
        window.WebViewJavascriptBridge.callHandler(
            'getOS', {}, function (responseData) {
                os = responseData;
                seccus(responseData);
            })
    },
    setDB: function (dbName) {
        return DB.SetDB(dbName);
    },
    createDB: function (dbName) {
        return DB.CreateDB(dbName);
    },
    execSQL: function (sql) {
        return DB.ExecSQL(sql);
    },
    getDataTable: function (sql) {
        return DB.GetDataTable(sql);
    },
    downloadH5App: function (url) {
        return WebView.DownloadH5App(url);
    },
    setHttpServer: function (_httpServer) {
        WebView.setHttpServer(_httpServer);
    },
    ajaxSend: function (url, dataPOST) {
        return WebView.AjaxSend(url, dataPOST);
    },
    ajaxSendAsync: function (url, dataPOST, succes) {
        window.WebViewJavascriptBridge.callHandler(
            'AjaxSendAsync', { 'url': url, 'dataPOST': dataPOST },
            function (responseData) {
                succes(responseData);
            }
        );
    },
    loadUrl: function (url) {
        window.location.href = url;
    },
    scanBarcode: function (succes) {
        window.WebViewJavascriptBridge.callHandler(
            'ScanBarcode', {},
            function (responseData) {
                succes(responseData);
            }
        );
    },
    getLocation: function () {
        return WebView.GetLocation();
    },
    getCamera: function (succes) {
        window.WebViewJavascriptBridge.callHandler(
            'GetCamera', {},
            function (responseData) {
                succes(responseData);
            }
        );
    },
    shake: function () {
        WebView.Shake();
    },
    dial: function (telNumber) {
        WebView.Dial(telNumber);
    },
    startAndroidService_01: function (serverUrl, userKey, password) {
        WebView.startAndroidService_01(serverUrl, userKey, password);
    },
    stopAndroidService_01: function () {
        WebView.stopAndroidService_01();
    },
    startIOSService_01: function (Name, time) {
        window.WebViewJavascriptBridge.callHandler(
            'IOSService', { "Name": Name, "time": time }
        );
    },
    showErr: function (errMessage) {
        alert(errMessage);
    },
    debug: function (debugMessage) {
        alert(debugMessage);
    }
}
initAppOS();
// ----------------------------------------------------------------------------
function initAppOS() {
    if (window.WebView) {
        try {
            App.getOS(function (result) {
                App.os = result;
            });
        }
        catch (e) {
            alert("xwf.app.js::initAppOS 遇到意外错误: " + e.toString());
        }
    }
    else {
        App.os = "windows";
    }
}