﻿/*
* xwf.ajax JavaScript Library v1.0
* Author: Volant Lee
* Create Date: 2012-06-27
* Copyright 2012-2018, xpas-next.com
* Description: 微信主窗口(topWin)
*/
var topWin = {                          // -- 全局对象 --
    systemName: "",                     // -- 子系统名称(例如：xpas，即项目目录) --
    up: {},                             // -- user parameters 每个子系统下传 --

    officeId: 0,
    officeNodeKey: "",
    officeName: "",
    officeShortname: "",

    office0Id: 0,
    office0Name: "",
    office0Shortname: "",
    office1Id: 0,
    office1Name: "",
    office1Shortname: "",
    office2Id: 0,
    office2Name: "",
    office2Shortname: "",

    userKey: "",
    userName: "",
    nickname: "",
    groupKeys: "",
    isDeveloper: false,

    dtbMenu: null,
    remark: ""
};

function initTopWin() {
    // -- 初始化窗口类 ------------------------------------
    var jsonProp = {
        zIndex: 30000,
        rangeContainer: window.document.documentElement
    };
    topWin.cWin = new window.xwf_window(jsonProp);
}

// -- 打开窗口、全屏窗口、顶级视图 --------------------------------------------
topWin.openWindow = function (prop, para) {
    prop.topWin = this;
    return topWin.cWin.openWindow(prop, para);
};
topWin.openFullWindow = function (prop, para) {
    prop.noTitle = true;
    prop.windowState = "maximized";
    return this.openWindow(prop, para);
};

// -- 辅助函数 ----------------------------------------------------------------
topWin.matchGroup = function (strGroupKeys) {
    if (strGroupKeys == null || strGroupKeys.equals("")) return false;
    var arrKeys = this.groupKeys.split(",");

    strGroupKeys = "," + strGroupKeys.toLowerCase().replaceAll(";", ",") + ",";
    for (var i = 0; i < arrKeys.length; i++) {
        if (strGroupKeys.indexOf("," + arrKeys[i].toLowerCase() + ",") >= 0) {
            return true;
        }
    }
    return false;
};
topWin.matchUser = function (strUserKeys) {
    if (strUserKeys == null || strUserKeys.equals("")) return false;
    var arrKeys = strUserKeys.replaceAll(";", ",").split(",");
    for (var i = 0; i < arrKeys.length; i++) {
        if (this.userKey.equals(arrKeys[i])) {
            return true;
        }
    }
    return false;
};