﻿var topWin = {                  // -- 全局对象 --
    os: urlPara.os,             // -- 客户端操作系统 --
    loginUrl: urlPara["loginUrl"] || (g.appPath + "project/xpas/html/login.html"),   // -- 登录来源url --
    db: "",                     // -- 全局数据库连接对象(SQLite) --

    eoId: 0,
    doId: 0,
    officeId: 0,
    officeName: "",
    officeNodeKey: "",
    officeShortname: "",

    userKey: "",
    userName: "",
    nickname: "",
    groupKeys: "",

    win: window,
    doc: document,
    cWin: null,                 // -- 窗口类 --
    context: null               // -- 全局上下文菜单实例 --
};

function initTopWin() {
    // -- 初始化窗口类 ------------------------------------
    var jsonProp = {
        zIndex: 30000,
        rangeContainer: window.document.documentElement
    };
    topWin.cWin = new window.xwf_window(jsonProp);

    // -- 初始化上下文菜单类 ------------------------------
    topWin.context = new window.xmf_context({ menuClick: null });
}

// -- 打开窗口、全屏窗口、顶级视图 --------------------------------------------
topWin.openWindow = function (prop, para) {
    prop.topWin = this;
    return topWin.cWin.openWindow(prop, para);
};
topWin.openFullWindow = function (prop, para) {
    prop.noTitle = true;
    prop.windowState = "maximized";
    return this.openWindow(prop, para);
};

topWin.openTopView = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html_mobile/frame/uview.html";
    return this.openFullWindow(prop, para);
};
topWin.openReport = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/report/reportview.html";
    return this.openFullWindow(prop, para);
};

topWin.openFlowData = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/flow/flow_data.html";
    prop.modal = true;

    return this.openWindow(prop, para);
}

// -- 上传、下载文件 ----------------------------------------------------------
topWin.uploadFile = function (prop, para) {
    prop.url = g.appPath + "project/xpas/html/util/upload_file.html";
    prop.modal = true;

    return this.openWindow(prop, para);
}
topWin.downloadFile = function (urlFile) {
    window.open(g.xpasRunPath + urlFile + "?rnd=" + Math.random());
};

// -- 辅助函数 ----------------------------------------------------------------
topWin.matchGroup = function (strGroupKeys) {
    if (strGroupKeys == null || strGroupKeys.equals("")) return false;
    var arrKeys = this.groupKeys.split(",");

    strGroupKeys = "," + strGroupKeys.toLowerCase().replaceAll(";", ",") + ",";
    for (var i = 0; i < arrKeys.length; i++) {
        if (strGroupKeys.indexOf("," + arrKeys[i].toLowerCase() + ",") >= 0) {
            return true;
        }
    }
    return false;
};
topWin.matchUser = function (strUserKeys) {
    if (strUserKeys == null || strUserKeys.equals("")) return false;
    var arrKeys = strUserKeys.replaceAll(";", ",").split(",");
    for (var i = 0; i < arrKeys.length; i++) {
        if (this.userKey.equals(arrKeys[i])) {
            return true;
        }
    }
    return false;
};

// -- 将服务器数据同步到本地数据库 --------------------------------------------
function syncServer(systemKey) {
    try {
        if (g.a.send("processType=com.xznext.Framework&actionType=getMenu", { systemKey: systemKey, clientType: "APP" }, true)) {
            if (g.a.OK) {
                var cReturn = g.a.cReturn;
                var dtbMenu = cReturn.dtbMenu;
                if (dtbMenu.rowCount == 0) {
                    //alert("尚未为您分配当前系统访问权限，请与系统管理员联系。");
                    return false;
                }
                if (!db.syncTable({ tableName: "ST_MENU", dtbServer: dtbMenu, syncColumn: "none", syncDelete: "delete", syncData: "append" })) {
                    alert("同步菜单遇到意外错误，请重试。");
                    return false;
                }
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    catch (e) {
        alert(e.toString());
        return false;
    }
    return true;
}