﻿/*
* eXtensible Mobile Framework SQLite JavaScript Library v1.0
* Author: Volant Lee
* Create Date: 2016-12-20
* Modify Date: 2016-12-20
* Copyright 2016, http://www.xpas-next.com/
* Description: SQLite 
*/

var db = {
    conn: null
};

// -- 打开数据库 --------------------------------------------------------------
db.openDatabase = function openDatabase(dbName, dbPath) {
    if (g.b.ie) {
        try {
            db.conn = new ActiveXObject("ADODB.Connection");
            db.conn.ConnectionString = "DRIVER=SQLite3 ODBC Driver;AutoTranslate=False;NoWCHAR=1;Database=" + dbPath + dbName + ".db";
            db.conn.Open();
            return true;
        }
        catch (e) {
            alert(e.toString());
            return false;
        }
    }
    else {
        var blReturn = false;
        blReturn = App.createDB(dbName);

        return App.setDB(dbName);
    }
};

db.execSQL = function (sql) {
    var nResult = 0;
    if (g.b.ie) {
        try {
            nResult = db.conn.Execute(sql);
            return 0;
        }
        catch (e) {
            alert(e.toString());
            return -1;
        }
    }
    else {
        nResult = App.execSQL(sql);
        if (nResult < 0) {
            alert("SQL执行失败");
        }
    }
};
db.getDataTable = function (sql) {
    var strResult = "";

    var dtb = new xwf_datatable();
    // -- Android -----------------------------------------
   
    if (!g.b.ie) {        
        strResult = App.getDataTable(sql);
        if (strResult.length > 0) {
            var arrValues = strResult.split(g.c.CHAR7);
            dtb.readFromData(arrValues[0], arrValues[1]);
            return dtb;
        }
        return null;
    }
    // -- ADO ---------------------------------------------    
    var rowCount = 0, colCount = 0;
    var columnValue = "";

    var arrField = new Array();
    var arrData = new Array();
    var rs = null;
    // ----------------------------
    try {
        rs = db.conn.Execute(sql);
        colCount = rs.Fields.Count;
        for (var iCol = 0; iCol < colCount; iCol++) {
            if (iCol > 0) {
                arrField.push(g.c.CHAR1);
            }
            arrField.push("name" + g.c.CHAR3 + rs.Fields(iCol).name);
            arrField.push(g.c.CHAR2 + "dataType" + g.c.CHAR3 + "varchar");
            arrField.push(g.c.CHAR2 + "columnType" + g.c.CHAR3 + "string");
        }
        // ----------------------------
        while (!rs.eof) {
            if (rowCount++ > 0) {
                arrData.push(g.c.CHAR1);
            }
            for (var iCol = 0; iCol < colCount; iCol++) {
                if (iCol > 0) {
                    arrData.push(g.c.CHAR2);
                }
                columnValue = rs.Fields(iCol).value;
                arrData.push(columnValue);
            }
            rs.movenext();
        }
        // ----------------------------
        dtb.readFromData(arrField.join(""), arrData.join(""));
        return dtb;
    }
    catch (e) {
        alert(e.toString());
        return null;
    }
    finally {
        try {
            rs.close();
        }
        catch (e) {
            alert(e.toString());
        }
    }
};

db.getInt = function (sql) {
    var strValue = null;
    var dtb = db.getDataTable(sql);
    if (dtb.rowCount != 1) {
        return null;
    }
    else {
        strValue = dtb.rows[0][0].value;
        return strValue.toInt();
    }
};

// -- 同步服务器表结构及数据 --------------------------------------------------
db.syncTable = function (jsonPara) {
    var nResult = 0;
    var sql = "", sqlCreat = "", sqlInsert = "", sqlFields = "";
    var tableName = "", columnName = "", columnType = "", columnValue = "";
    var arrFields = new Array(), arrValues = new Array();

    var json = {
        tableName: "",
        dtbServer: null,
        syncColumn: "none",     // -- append：追加列；drop：删除表重建 --
        syncDelete: "none",     // -- delete：先删除数据 --
        syncData: "none"        // -- append：追加数据； --
    };
    var dtbServer = null;
    // ----------------------------------------------------
    try {
        json = g.x.extendJSON(json, jsonPara);
        tableName = json.tableName;
        dtbServer = json.dtbServer;
        // -- 同步表结构 ----------------------------------
        nResult = db.getInt("SELECT COUNT(*) num1 FROM sqlite_master WHERE type = 'table' AND name = '" + tableName + "'");
        if (nResult == 1) {
            if (json.syncColumn.equals("drop")) {
                nResult = db.getInt("DROP TABLE " + tableName);
                if (nResult < 0) {
                    alert("删除表：" + tableName + "失败，请重试。");
                    return false;
                }
                nResult = 0;
            }
            else if (json.syncColumn.equals("append")) {
                alert("追加字段尚未实现。");
                return false;
            }
        }
        if (nResult == 0) {
            for (var i = 0; i < dtbServer.columnCount; i++) {
                columnName = dtbServer.columns[i].name;
                columnType = dtbServer.columns[i].columnType;

                sqlCreat += columnName + " varchar(255)";
                if (i < dtbServer.columnCount - 1) {
                    sqlCreat += ",";
                }
            }
            sqlCreate = "CREATE TABLE " + tableName + "(" + sqlCreat + ")";
            nResult = db.execSQL(sqlCreate);
            if (nResult < 0) {
                alert("创建表：" + tableName + "失败，请重试。");
                return false;
            }
            else {
                // alert("创建表：" + tableName + "成功。");
            }
        }
        // -- 同步表数据 ----------------------------------
        if (json.syncDelete.equals("delete")) {
            nResult = db.execSQL("DELETE FROM " + tableName);
            if (nResult < 0) {
                alert("删除表：" + tableName + "数据失败，请重试。");
                return false;
            }
        }
        if (json.syncData.equals("append")) {
            for (var i = 0; i < dtbServer.columnCount; i++) {
                arrFields.push(dtbServer.columns[i].name);
            }
            sqlFields = "INSERT INTO " + tableName + "(" + arrFields.join(",") + ") VALUES (";

            for (var iRow = 0; iRow < dtbServer.rowCount; iRow++) {
                arrValues = new Array();
                for (var iCol = 0; iCol < dtbServer.columnCount; iCol++) {
                    arrValues.push(dtbServer.rows[iRow][iCol].value);
                }
                sqlInsert = sqlFields + "'" + arrValues.join("','") + "')";
                nResult = db.execSQL(sqlInsert);
                if (nResult < 0) {
                    alert("插入表：" + tableName + "数据失败，请重试。\n" + sqlInsert);
                    return false;
                }
            }
        }
    }
    catch (e) {
        alert(e.toString());
        return false;
    }
    finally {
    }
    return true;
}