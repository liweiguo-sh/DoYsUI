﻿// -- 动态加载样式表 ----------------------------------------------------------
javascriptBefore();
cssGlobal();
javascriptAfter();

function javascriptBefore() {
    // -- jQuery、Bootstrap -------------------------------
    document.write("<script src='" + g.pluginPath + "jquery/jquery-3.1.1.min.js' type='text/javascript'></script>");
    // document.write("<script src='" + g.pluginPath + "bootstrap/js/bootstrap.min.js' type='text/javascript'></script>");

    // -- xpas 基础类库 -----------------------------------
    document.write("<script src='" + g.appPath + "res/jscript/xwf.datatable.js' type='text/javascript'></script>");

    // -- xpas 标准控件 -----------------------------------

    // -- 第三方通用控件 ----------------------------------

}
function cssGlobal() {
    var css_style = top.cssStyle + "/"; 
}
function javascriptAfter() {

}