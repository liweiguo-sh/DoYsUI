﻿/*
* xwf.weixin JavaScript Library v1.0
* Author: Steven won
* Create Date: 2016-04-06
* Modify Date: 2016-06-04
* Copyright 2016
* Description: 微信功能包，包含拍照上传图片，录音上传等 
* 特别说明：引用此JS必须要同时引用微信的js   <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
*           在窗体加载完毕后再创建由于加载时间的关系，可以在wx.ready=function(){开放微信操作的代码}
*/

// -- 类定义 ------------------------------------------------------------------

window.xwf_weixin = function (jsonProp) {

    ///<summary>微信控件，实现通过微信实现手机拍照，录音等功能</summary>
    if (jsonProp == null) return;
    for (var key in jsonProp) {
        this[key] = jsonProp[key];
    }

    // -- 初始化类 ----------------------------------------
    this.init();
};
window.xwf_weixin.prototype = {
    serviceKey: "",                     //公众号serviceKey yihaojiaolian
    appId: "",                          //公众号appId,wxfbb8102d85b7d2a3 exp
    isDebug: false,                        //是否开启DEBUG模式
    // ----------------------------------------------------
    summary: function () {
        var strSummary = "JavaScript实现微信的手机访问, 用法参考.net weixin.";
        return strSummary;
    }
};
window.xwf_weixin.prototype.init = function () {
    //初始化微信
    var ajaxPara = {
        serviceKey: this.serviceKey,
        url: window.location.href        //一定要域名调用，wx的规定，没办法
    };

    if (g.a.send("processType=com.xznext.weixin.WeixinTools&actionType=getWxJsConfig", ajaxPara, true)) {
        if (g.a.OK) {

            wx.config({
                debug: this.isDebug,
                appId: this.appId,
                timestamp: g.a.cReturn.timeStamp,
                nonceStr: g.a.cReturn.nonceStr,
                signature: g.a.cReturn.jsSignature,
                jsApiList: ['checkJsApi', 'startRecord', 'stopRecord',
                    'onRecordEnd', 'playVoice', 'pauseVoice', 'stopVoice',
                    'uploadVoice', 'downloadVoice', 'chooseImage',
                    'previewImage', 'uploadImage', 'downloadImage',
                    'getNetworkType', 'scanQRCode']
            });

            wx.error(function (res) {
                alert(res.errMsg);
            });

        }
    }
};
//-- 调用扫码 --
window.xwf_weixin.prototype.scanQR = function (jsonIn) {
    wx.scanQRCode({
        desc: jsonIn.desc,
        needResult: jsonIn.needResult,//0, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
        scanType: ["qrCode", "barCode"], // 可以指定扫二维码还是一维码，默认二者都有
        success: jsonIn.success //function (res) {var result = res.resultStr; // 当needResult 为 1 时，扫码返回的结果 }
    });
};
//-- 拍照 -----------------------------------------------------
window.xwf_weixin.prototype.selectOnePicture = function (jsonIn) {

    var jsonPara = {
        fileName: "_auto",    //fileName,urlPath =“_auto”或“”或传入 都视为自动
        urlPath: "_auto",     //
        callback: null
    };

    for (var key in jsonIn) {
        jsonPara[key] = jsonIn[key];
    }

    if (jsonPara.fileName == "") {
        jsonPara.fileName == "_auto";
    }
    if (jsonPara.urlPath == "") {
        jsonPara.urlPath == "_auto";
    }

    //记录this
    var _this = this;
    wx.chooseImage({
        success: function (res) {
            if (res.localIds.length == 1) {//选择成功后，立刻上传

                wx.uploadImage({
                    localId: res.localIds[0],
                    success: function (res) {
                        var ajaxPara = {//调用参数
                            serviceKey: _this.serviceKey,
                            mediaKey: res.serverId,
                            mediaType: "0",
                            fileName: jsonPara.fileName,
                            urlPath: jsonPara.urlPath
                        };

                        var callbackPara = {//返回参数
                            fileName: "",
                            urlPath: "",
                            realPath: ""
                        };
                        if (g.a.send("processType=com.xznext.weixin.WeixinTools&actionType=saveWxMedia", ajaxPara, true)) {
                            if (g.a.OK) {
                                var cReturn = g.a.cReturn;
                                callbackPara.fileName = cReturn.fileName;
                                callbackPara.urlPath = cReturn.urlPath;
                                callbackPara.realPath = cReturn.realPath;
                            }
                        }

                        jsonPara.callback(callbackPara);

                    },
                    fail: function (res) {
                        showErr(JSON.stringify(res));
                    }
                });
            } else {
                showErr("只能选择一幅图片！");
            }
        }
    });

};

